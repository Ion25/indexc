package com.example.carteraclientes_v11;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.carteraclientes_v11.BaseDatos.BaseDeDatos;

public class ConsultarUsuarioActivity extends AppCompatActivity {

    EditText campoId,campoNombre,campoTelefono,campoEmail;

    ConexionSQLiteHelper conn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar_usuario);

        conn = new ConexionSQLiteHelper(getApplicationContext(),"bd_usuarios",null,1);

        campoId= (EditText) findViewById(R.id.documentoId);
        campoNombre= (EditText) findViewById(R.id.campoNombreConsulta);
        campoTelefono= (EditText) findViewById(R.id.campoTelefonoConsulta);
        campoEmail= (EditText) findViewById(R.id.campoEmailConsulta);


    }

    public void onClick(View view) {

        switch (view.getId()){
            case R.id.btnConsultar:
//                consultar();
                consultarSql();
                break;
            case R.id.btnActualizar: actualizarUsuario();
                break;
            case R.id.btnEliminar: eliminarUsuario();
                break;
        }

    }

    private void eliminarUsuario() {
        SQLiteDatabase db = conn.getWritableDatabase();
        String[] parametros={campoId.getText().toString()};

        db.delete(BaseDeDatos.TABLA_USUARIO,BaseDeDatos.CAMPO_ID+"=?",parametros);
        Toast.makeText(getApplicationContext(),"Ya se Eliminó el usuario",Toast.LENGTH_LONG).show();
        campoId.setText("");
        limpiar();
        db.close();
    }

    private void actualizarUsuario() {
        SQLiteDatabase db = conn.getWritableDatabase();
        String[] parametros={campoId.getText().toString()};
        ContentValues values=new ContentValues();
        values.put(BaseDeDatos.CAMPO_NOMBRE,campoNombre.getText().toString());
        values.put(BaseDeDatos.CAMPO_TELEFONO,campoTelefono.getText().toString());
        values.put(BaseDeDatos.CAMPO_EMAIL, campoEmail.getText().toString());

        db.update(BaseDeDatos.TABLA_USUARIO,values,BaseDeDatos.CAMPO_ID+"=?",parametros);
        Toast.makeText(getApplicationContext(),"Ya se actualizó el usuario",Toast.LENGTH_LONG).show();
        db.close();

    }

    private void consultarSql() {
        SQLiteDatabase db=conn.getReadableDatabase();
        String[] parametros={campoId.getText().toString()};

        try {
            //select nombre,telefono from usuario where codigo=?
            Cursor cursor=db.rawQuery("SELECT "+ BaseDeDatos.CAMPO_NOMBRE+","+ BaseDeDatos.CAMPO_TELEFONO+","+ BaseDeDatos.CAMPO_EMAIL +
                    " FROM "+ BaseDeDatos.TABLA_USUARIO+" WHERE "+ BaseDeDatos.CAMPO_ID+"=? ",parametros);

            cursor.moveToFirst();
            campoNombre.setText(cursor.getString(0));
            campoTelefono.setText(cursor.getString(1));
            campoEmail.setText(cursor.getString(2));

        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"El documento no existe",Toast.LENGTH_LONG).show();
            limpiar();
        }

    }

    private void consultar() {
        SQLiteDatabase db=conn.getReadableDatabase();
        String[] parametros={campoId.getText().toString()};
        String[] campos={BaseDeDatos.CAMPO_NOMBRE,BaseDeDatos.CAMPO_TELEFONO,BaseDeDatos.CAMPO_EMAIL};

        try {
            Cursor cursor =db.query(BaseDeDatos.TABLA_USUARIO,campos,BaseDeDatos.CAMPO_ID + "=?",parametros,null,null,null);
            cursor.moveToFirst();
            campoNombre.setText(cursor.getString(0));
            campoTelefono.setText(cursor.getString(1));
            campoEmail.setText(cursor.getString(2));
            cursor.close();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"El documento no existe",Toast.LENGTH_LONG).show();
            limpiar();
        }


    }

    private void limpiar() {
        campoNombre.setText("");
        campoTelefono.setText("");
        campoEmail.setText("");
    }

}