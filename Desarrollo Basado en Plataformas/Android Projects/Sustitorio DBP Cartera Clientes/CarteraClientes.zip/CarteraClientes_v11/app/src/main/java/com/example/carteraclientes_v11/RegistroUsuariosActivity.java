package com.example.carteraclientes_v11;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.carteraclientes_v11.BaseDatos.BaseDeDatos;

public class RegistroUsuariosActivity extends AppCompatActivity {

    EditText campoId,campoNombre,campoTelefono,campoEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuarios);

        campoId= (EditText) findViewById(R.id.campoId);
        campoNombre= (EditText) findViewById(R.id.campoNombre);
        campoTelefono= (EditText) findViewById(R.id.campoTelefono);
        campoEmail= (EditText) findViewById(R.id.campoEmail);

    }

    public void onClick(View view) {
        registrarUsuarios();
        //registrarUsuariosSql();
    }

    private void registrarUsuariosSql() {
        ConexionSQLiteHelper conn=new ConexionSQLiteHelper(this,"bd_usuarios",null,1);

        SQLiteDatabase db=conn.getWritableDatabase();

        //insert into usuario (id,nombre,telefono) values (123,'Cristian','85665223')

        String insert="INSERT INTO "+ BaseDeDatos.TABLA_USUARIO
                +" ( " + BaseDeDatos.CAMPO_ID+","+ BaseDeDatos.CAMPO_NOMBRE+","+ BaseDeDatos.CAMPO_TELEFONO+"," +BaseDeDatos.CAMPO_EMAIL+")" +
                " VALUES ("+campoId.getText().toString()+", '"+campoNombre.getText().toString()+"','"
                +campoTelefono.getText().toString()+"','"+campoEmail.getText().toString() +"')";

        db.execSQL(insert);


        db.close();
    }


    private void registrarUsuarios() {
        ConexionSQLiteHelper conn=new ConexionSQLiteHelper(this,"bd_usuarios",null,1);

        SQLiteDatabase db=conn.getWritableDatabase();

        ContentValues values=new ContentValues();
        values.put(BaseDeDatos.CAMPO_ID,campoId.getText().toString());
        values.put(BaseDeDatos.CAMPO_NOMBRE,campoNombre.getText().toString());
        values.put(BaseDeDatos.CAMPO_TELEFONO,campoTelefono.getText().toString());
        values.put(BaseDeDatos.CAMPO_EMAIL, campoEmail.getText().toString());

        Long idResultante=db.insert(BaseDeDatos.TABLA_USUARIO,BaseDeDatos.CAMPO_ID,values);

        Toast.makeText(getApplicationContext(),"Id Registro: "+idResultante,Toast.LENGTH_SHORT).show();
        db.close();
    }
}