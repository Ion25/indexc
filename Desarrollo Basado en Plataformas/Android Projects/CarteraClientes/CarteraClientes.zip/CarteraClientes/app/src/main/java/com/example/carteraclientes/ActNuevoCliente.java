package com.example.carteraclientes;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.example.carteraclientes.BaseDatos.FeedReaderContract;
import static com.example.carteraclientes.BaseDatos.FeedReaderContract.FeedEntry;
import com.example.carteraclientes.BaseDatos.FeedReaderDbHelper;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ActNuevoCliente extends AppCompatActivity {

    private EditText edtNombre;
    private EditText edtDireccion;
    private EditText edtEmail;
    private EditText edtTelefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_nuevo_cliente);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        edtNombre = findViewById(R.id.edtNombre);
        edtDireccion = findViewById(R.id.edtDireccion);
        edtEmail = findViewById(R.id.edtEmail);
        edtTelefono = findViewById(R.id.edtTelefono);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_nuevo_cliente, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch(id){
            case R.id.action_ok:
                if(bCamposCorrectos())
                {
                    try {
                        FeedReaderDbHelper dbHelper = new FeedReaderDbHelper(this);

                        // Gets the data repository in write mode
                        SQLiteDatabase db = dbHelper.getWritableDatabase();

                        // Create a new map of values, where column names are the keys

                        ContentValues values = new ContentValues();
                        values.put(FeedEntry.COLUMN_NAME, edtNombre.getText().toString().trim());
                        values.put(FeedEntry.COLUMN_DIRECCION, edtDireccion.getText().toString().trim());
                        values.put(FeedEntry.COLUMN_EMAIL, edtEmail.getText().toString().trim());
                        values.put(FeedEntry.COLUMN_TELEFONO, edtTelefono.getText().toString().trim());


                        // Insert the new row, returning the primary key value of the new row
                        long newRowId = db.insert(FeedEntry.TABLE_NAME, null, values);

                        String insert = " INSERT INTO " + FeedEntry.TABLE_NAME + "("
                                + FeedEntry.COLUMN_NAME + ", "
                                + FeedEntry.COLUMN_DIRECCION + ", "
                                + FeedEntry.COLUMN_EMAIL + ", "
                                + FeedEntry.COLUMN_TELEFONO + ")"
                                + " VALUES ('" + edtNombre.getText().toString().trim() + ", "
                                + edtDireccion.getText().toString().trim() + ", "
                                + edtEmail.getText().toString().trim() + ", "
                                + edtTelefono.getText().toString().trim() + "')";

                        db.execSQL(insert);
                        finish();

                    }catch (Exception ex) {
                        AlertDialog.Builder dlg = new AlertDialog.Builder(this);
                        dlg.setTitle("Aviso");
                        dlg.setMessage(ex.getMessage());
                        dlg.setNeutralButton("Ok", null);
                        dlg.show();
                    }
                }
                else
                {
                    AlertDialog.Builder dlg = new AlertDialog.Builder(this);
                    dlg.setTitle("Aviso");
                    dlg.setMessage("Existen campos vacíos");
                    dlg.setNeutralButton("Ok", null);
                    dlg.show();
                }
                //Toast.makeText(this, "Botón Ok seleccionado", Toast.LENGTH_SHORT).show();
                break;

            case R.id.action_cancelar:
                //Toast.makeText(this, "Botón Cancelar seleccionado", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean bCamposCorrectos() {
        boolean res = true;
        if(edtNombre.getText().toString().trim().isEmpty()) {
            edtNombre.requestFocus();
            res = false;
        }
        if(edtDireccion.getText().toString().trim().isEmpty()) {
            edtNombre.requestFocus();
            res = false;
        }
        if(edtEmail.getText().toString().trim().isEmpty()) {
            edtEmail.requestFocus();
            res = false;
        }
        if(edtTelefono.getText().toString().trim().isEmpty()) {
            edtTelefono.requestFocus();
            res = false;
        }
        return res;
    }

}