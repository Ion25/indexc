package com.example.carteraclientes.BaseDatos;

import android.provider.BaseColumns;

public class DatosOpenHelper {
}

