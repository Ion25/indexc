package com.example.carteraclientes.BaseDatos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class FeedReaderContract {
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private FeedReaderContract() {}

    /* Inner class that defines the table contents */
    public static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME = "Clientes";
        public static final String COLUMN_NAME = "Nombre";
        public static final String COLUMN_DIRECCION = "Direccion";
        public static final String COLUMN_EMAIL = "Email";
        public static final String COLUMN_TELEFONO = "Telefono";
        //public static final String COLUMN_NAME_SUBTITLE = "subtitle";
    }

    static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + FeedEntry.TABLE_NAME + " (" +
                    FeedEntry._ID + " INTEGER PRIMARY KEY," +
                    FeedEntry.COLUMN_NAME + " TEXT," +
                    FeedEntry.COLUMN_DIRECCION + " TEXT," +
                    FeedEntry.COLUMN_EMAIL + " TEXT," +
                    FeedEntry.COLUMN_TELEFONO + " TEXT)";

    static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + FeedEntry.TABLE_NAME;



}
