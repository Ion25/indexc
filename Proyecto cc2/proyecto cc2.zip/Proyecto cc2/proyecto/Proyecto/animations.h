#pragma once
#include <SFML/Graphics.hpp>

class Animations
{
public:
    Animations(sf::Texture *texture, sf::Vector2u cantImages, float switchTime);
    ~Animations();

    void Update(int row, float deltaTime, bool faceRight);

    sf::IntRect uvRect;
    bool murio;

private:
    sf::Vector2u currentImage;
    sf::Vector2u imageCount;
    float totalTime;
    float switchTime;
};
