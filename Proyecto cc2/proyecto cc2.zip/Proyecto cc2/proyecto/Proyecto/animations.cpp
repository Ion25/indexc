#include "animations.h"

Animations::Animations(sf::Texture *texture, sf::Vector2u cantImages, float switchTime)
{
    this->imageCount = cantImages;
    this->switchTime = switchTime;
    totalTime = 0.0f;
    currentImage.x = 0;

    //Medidas Jugador
    uvRect.width = texture->getSize().x / float(cantImages.x);
    uvRect.height = texture->getSize().y / float(cantImages.y);
}

Animations::~Animations()
{

}

void Animations::Update(int row, float deltaTime, bool faceRight)
{
    if (currentImage.y != row)
    {
        currentImage.x = 0;
    }

	currentImage.y = row;
	totalTime += deltaTime;


	if (totalTime >= switchTime)
	{
		totalTime -= switchTime;
		currentImage.x++;

		if (currentImage.x >= imageCount.x)
		{
			currentImage.x = 0;
		}
	}
	uvRect.top = currentImage.y * uvRect.height;

	if(faceRight)
	{
		uvRect.left = (currentImage.x * uvRect.width);
		uvRect.width = abs(uvRect.width);
	}
	else
	{
		uvRect.left = (currentImage.x + 1) * abs(uvRect.width);
		uvRect.width = -abs(uvRect.width);
	}
	/*
	if (dead && currentImage.x > 8)
		murio = true;
	else
		murio = false;*/
}
