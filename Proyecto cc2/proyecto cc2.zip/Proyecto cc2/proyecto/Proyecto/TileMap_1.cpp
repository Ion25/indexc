#include "TileMap_1.h"
#include <iostream>

TileMap_1::TileMap_1(std::string  texture, unsigned int nLevelWidth, unsigned int nLevelHeight, std::string sLevel, unsigned int nTileWidth, unsigned int nTileHeight)
    :    nLevelWidth(nLevelWidth), nLevelHeight(nLevelHeight), sLevel(sLevel), nTileWidth(nTileWidth), nTileHeight(nTileHeight)
{

    textura_Tiles.loadFromFile("Tiles.png");
    textura_Tiles1.loadFromFile("plat.png");
    textura_Tiles2.loadFromFile("suelo.png");
    textura_Tiles3.loadFromFile("ladrillo.png");

    auto GetTile = [&](int x, int y)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			return sLevel[y * nLevelWidth + x];
		else
			return ' ';
	};

	auto SetTile = [&](int x, int y, char c)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			sLevel[y * nLevelWidth + x] = c;

	};

	for (int x = 0; x < nLevelWidth; x++)
	{
		for (int y = 0; y < nLevelHeight; y++)
		{
			Tiles[x + y * nLevelWidth].setPosition(x * nTileWidth, y * nTileHeight);
			Tiles[x + y * nLevelWidth].setSize(sf::Vector2f(nTileWidth, nTileHeight));

			wchar_t sTileID = GetTile(x, y);
			switch (sTileID)
			{
			case '.':

				//Tiles[x + y * nLevelWidth].setFillColor(sf::Color::Cyan);

				break;
			case 'q':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles2);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(0, 0, 301, 300));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'w':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles3);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128*1, 0, 256, 300));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;

			default:
				break;
			}

		}

	}


}

void TileMap_1::TileMapDraw(sf::RenderWindow & window, float deltaTime, Player & player)
{

    window.draw(sprite_background);

	for (sf::RectangleShape& Tile : vTiles)
	{
		window.draw(Tile);

	}



}

void TileMap_1::CheckCollisionTileMap(float fElapsedTime, sf::RenderWindow & window, Player & player) {

	player.inputHandler(window);
	player.setVelocity(player.GetVelocity().x*0.95f, player.GetVelocity().y*1.00999f);
	float fPlayerVelX = player.GetVelocity().x;
	float fPlayerVelY = player.GetVelocity().y;
	float fPlayerPosX = player.GetPosition().x/nTileWidth;

	float fPlayerPosY = player.GetPosition().y/nTileHeight;

	float playerHalfSize = player.getCollider().getHalfSize().x/ nTileWidth;

	fPlayerVelY += 20.0f * fElapsedTime;

	float fNewPlayerPosX = fPlayerPosX + fPlayerVelX * fElapsedTime;
	float fNewPlayerPosY = fPlayerPosY + fPlayerVelY * fElapsedTime;



	auto GetTile = [&](int x, int y)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			return sLevel[y * nLevelWidth + x];
		else
			return ' ';
	};
	auto SetTile = [&](int x, int y, wchar_t c)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			sLevel[y * nLevelWidth + x] = c;

	};

	if (fPlayerVelX <= 0) // Moving Left
	{
		//if (GetTile(fNewPlayerPosX + 0.0f, fPlayerPosY + 0.0f) != L'.' || GetTile(fNewPlayerPosX + 0.0f, fPlayerPosY + 0.9f) != L'.')
		if (GetTile(fNewPlayerPosX - playerHalfSize, fPlayerPosY - playerHalfSize) != L'.' || GetTile(fNewPlayerPosX - playerHalfSize, fPlayerPosY + playerHalfSize ) != L'.')
			{
			fNewPlayerPosX = (int)fNewPlayerPosX + 1;
			fPlayerVelX = 0;
		}
	}
	else // Moving Right
	{
		//if (GetTile(fNewPlayerPosX + 1.0f, fPlayerPosY + 0.0f) != L'.' || GetTile(fNewPlayerPosX + 1.0f, fPlayerPosY + 0.9f) != L'.')
		if (GetTile(fNewPlayerPosX + playerHalfSize, fPlayerPosY - playerHalfSize) != L'.' || GetTile(fNewPlayerPosX + playerHalfSize, fPlayerPosY + playerHalfSize) != L'.')
		{
			fNewPlayerPosX = (int)fNewPlayerPosX;
			fPlayerVelX = 0;

		}
	}

	player.setCanJump(false);
	if (fPlayerVelY <= 0) // Moving Up
	{
		if (GetTile(fNewPlayerPosX - playerHalfSize, fNewPlayerPosY - playerHalfSize) != L'.' || GetTile(fNewPlayerPosX + playerHalfSize, fNewPlayerPosY- playerHalfSize) != L'.')
		{
			fNewPlayerPosY = (int)fNewPlayerPosY + 1;
			fPlayerVelY = 0;
		}
	}
	else // Moving Down
	{
		if (GetTile(fNewPlayerPosX - playerHalfSize, fNewPlayerPosY + playerHalfSize) != L'.' || GetTile(fNewPlayerPosX + playerHalfSize, fNewPlayerPosY + playerHalfSize) != L'.')
		{
			fNewPlayerPosY = (int)fNewPlayerPosY;
			fPlayerVelY = 0;
			player.setCanJump(true); // Player has a solid surface underfoot
									//nDirModX = 0;
		}
	}
	// Apply new position
	fNewPlayerPosX = fPlayerPosX + fPlayerVelX * fElapsedTime;
	fNewPlayerPosY = fPlayerPosY + fPlayerVelY * fElapsedTime;
	player.setPosition(sf::Vector2f(fNewPlayerPosX*nTileWidth, fNewPlayerPosY*nTileHeight));
	player.setVelocity(fPlayerVelX, fPlayerVelY);

	player.Update(fElapsedTime, window);



}



