#pragma once
#include <SFML\Graphics.hpp>
#include "player.h"
#include <vector>

class TileMap_1
{
public:
    TileMap_1(std::string  texture, unsigned int nLevelWidth, unsigned int nLevelHeight, std::string sLevel, unsigned int nTileWidth, unsigned int nTileHeight);
	//bool load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height);

	void TileMapDraw(sf::RenderWindow & window, float deltaTime, Player & player);
	std::string texture;

	void CheckCollisionTileMap(float fElapsedTime, sf::RenderWindow & window, Player & player);

private:
    sf::Sprite sprite_arboles[9];
	sf::Sprite sprite_background;

	sf::RectangleShape body;
	sf::Texture textura_fondo;
	sf::Texture textura_Tiles;
	sf::Texture textura_Tiles1;
	sf::Texture textura_Tiles2;
	sf::Texture textura_Tiles3;

	sf::Texture textura_fondo2;


	std::string sLevel;
	unsigned int nLevelWidth;
	unsigned int nLevelHeight;
	unsigned int nTileWidth;
	unsigned int nTileHeight;

	sf::RectangleShape Tiles[40*30];

	std::vector<sf::RectangleShape> vTiles;

	/*
	virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
	{
		// apply the transform
		states.transform *= getTransform();

		// apply the tileset texture
		states.texture = &m_tileset;

		// draw the vertex array
		target.draw(m_vertices, states);

	}
	*/

	sf::VertexArray m_vertices;
	sf::Texture m_tileset;
};



