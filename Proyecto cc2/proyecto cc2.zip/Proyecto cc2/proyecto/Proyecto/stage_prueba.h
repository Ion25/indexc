#pragma once
#include<SFML/Graphics.hpp>
#include "Collider.h"
#include "Platform.h"
#include "player.h"
#include "stage_prueba.h"
#include <vector>
using namespace sf;

class stage0
{
public:
   	stage0(std::string fondo);
	void procesarColisionesStageX(Player & player);
	void Draw(sf::RenderWindow & window, float deltaTime, Player & player);
	Sprite procesarColisionesStage(Sprite player);
	Sprite getFondo();
	Sprite getPiso();
	Sprite getCajas(int i);

private:
	std::vector<Platform>  cajas;
	std::vector<Platform>  pisos;
	std::vector<Platform>  plat_movs;
	std::vector<Platform>  buttons;


	Platform * caja;
	Platform * piso;
	Platform * plat_mov;
	Platform * button;

	Sprite sprite_piso;
	Sprite sprite_cajas[5];
	Sprite sprite_plat_mov[2];
	Sprite sprite_button[3];

	Sprite sprite_arboles[4];
	Sprite sprite_background;

	Texture textura_piso;
	Texture textura_cajas;
	Texture textura_plat_mov;
	Texture textura_button;
	Texture textura_fondo;
	Texture textura_fondo2;

};

