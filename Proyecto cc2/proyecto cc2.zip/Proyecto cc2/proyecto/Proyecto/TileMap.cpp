#include "TileMap.h"
#include <iostream>

TileMap::TileMap(std::string  texture, unsigned int nLevelWidth, unsigned int nLevelHeight, std::string sLevel, unsigned int nTileWidth, unsigned int nTileHeight)
    :    nLevelWidth(nLevelWidth), nLevelHeight(nLevelHeight), sLevel(sLevel), nTileWidth(nTileWidth), nTileHeight(nTileHeight)
{

    textura_Tiles.loadFromFile("Tiles.png");
    textura_Tiles1.loadFromFile("plat.png");
    textura_Tiles2.loadFromFile("caja.png");

    auto GetTile = [&](int x, int y)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			return sLevel[y * nLevelWidth + x];
		else
			return ' ';
	};

	auto SetTile = [&](int x, int y, char c)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			sLevel[y * nLevelWidth + x] = c;

	};

	for (int x = 0; x < nLevelWidth; x++)
	{
		for (int y = 0; y < nLevelHeight; y++)
		{
			Tiles[x + y * nLevelWidth].setPosition(x * nTileWidth, y * nTileHeight);
			Tiles[x + y * nLevelWidth].setSize(sf::Vector2f(nTileWidth, nTileHeight));

			wchar_t sTileID = GetTile(x, y);
			switch (sTileID)
			{
			case '.':

				//Tiles[x + y * nLevelWidth].setFillColor(sf::Color::Cyan);

				break;
			case 'q':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(0, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'w':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128*1, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'e':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 2, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'a':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 3, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;

			case 's':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles2);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 4, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'd':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 5, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'z':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 6, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'x':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 7, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;

			case 'c':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 8, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'r':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 * 9, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 't':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 *10, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'f':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 *11, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;

			case 'g':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 *12, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'h':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 *13, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'b':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 *14, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;
			case 'y':

				Tiles[x + y * nLevelWidth].setTexture(&textura_Tiles);
				Tiles[x + y * nLevelWidth].setTextureRect(sf::IntRect(128 *15, 0, 128, 128));
				vTiles.push_back(Tiles[x + y * nLevelWidth]);
				break;

			default:
				break;
			}

		}

	}


}

void TileMap::TileMapDraw(sf::RenderWindow & window, float deltaTime, Player & player)
{

    window.draw(sprite_background);

	for (sf::RectangleShape& Tile : vTiles)
	{
		window.draw(Tile);

	}



}

void TileMap::CheckCollisionTileMap(float fElapsedTime, sf::RenderWindow & window, Player & player) {

	player.inputHandler(window);
	player.setVelocity(player.GetVelocity().x*0.91f, player.GetVelocity().y*0.99f);
	float fPlayerVelX = player.GetVelocity().x;
	float fPlayerVelY = player.GetVelocity().y;
	float fPlayerPosX = player.GetPosition().x/nTileWidth;
	float fPlayerPosY = player.GetPosition().y/nTileHeight;
	float playerHalfSize = player.getCollider().getHalfSize().x/ nTileWidth;
	fPlayerVelY += 20.0f * fElapsedTime;

	float fNewPlayerPosX = fPlayerPosX + fPlayerVelX * fElapsedTime;
	float fNewPlayerPosY = fPlayerPosY + fPlayerVelY * fElapsedTime;



	auto GetTile = [&](int x, int y)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			return sLevel[y * nLevelWidth + x];
		else
			return ' ';
	};
	auto SetTile = [&](int x, int y, wchar_t c)
	{
		if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
			sLevel[y * nLevelWidth + x] = c;

	};

	if (fPlayerVelX <= 0) // Moving Left
	{
		//if (GetTile(fNewPlayerPosX + 0.0f, fPlayerPosY + 0.0f) != L'.' || GetTile(fNewPlayerPosX + 0.0f, fPlayerPosY + 0.9f) != L'.')
		if (GetTile(fNewPlayerPosX - playerHalfSize, fPlayerPosY - playerHalfSize) != L'.' || GetTile(fNewPlayerPosX - playerHalfSize, fPlayerPosY + playerHalfSize ) != L'.')
			{
			fNewPlayerPosX = (int)fNewPlayerPosX + 1;
			fPlayerVelX = 0;
		}
	}
	else // Moving Right
	{
		//if (GetTile(fNewPlayerPosX + 1.0f, fPlayerPosY + 0.0f) != L'.' || GetTile(fNewPlayerPosX + 1.0f, fPlayerPosY + 0.9f) != L'.')
		if (GetTile(fNewPlayerPosX + playerHalfSize, fPlayerPosY - playerHalfSize) != L'.' || GetTile(fNewPlayerPosX + playerHalfSize, fPlayerPosY + playerHalfSize) != L'.')
		{
			fNewPlayerPosX = (int)fNewPlayerPosX;
			fPlayerVelX = 0;

		}
	}

	player.setCanJump(false);
	if (fPlayerVelY <= 0) // Moving Up
	{
		if (GetTile(fNewPlayerPosX - playerHalfSize, fNewPlayerPosY - playerHalfSize) != L'.' || GetTile(fNewPlayerPosX + playerHalfSize, fNewPlayerPosY- playerHalfSize) != L'.')
		{
			fNewPlayerPosY = (int)fNewPlayerPosY + 1;
			fPlayerVelY = 0;
		}
	}
	else // Moving Down
	{
		if (GetTile(fNewPlayerPosX - playerHalfSize, fNewPlayerPosY + playerHalfSize) != L'.' || GetTile(fNewPlayerPosX + playerHalfSize, fNewPlayerPosY + playerHalfSize) != L'.')
		{
			fNewPlayerPosY = (int)fNewPlayerPosY;
			fPlayerVelY = 0;
			player.setCanJump(true); // Player has a solid surface underfoot
									//nDirModX = 0;
		}
	}
	// Apply new position
	fNewPlayerPosX = fPlayerPosX + fPlayerVelX * fElapsedTime;
	fNewPlayerPosY = fPlayerPosY + fPlayerVelY * fElapsedTime;
	player.setPosition(sf::Vector2f(fNewPlayerPosX*nTileWidth, fNewPlayerPosY*nTileHeight));
	player.setVelocity(fPlayerVelX, fPlayerVelY);

	player.Update(fElapsedTime, window);



}

