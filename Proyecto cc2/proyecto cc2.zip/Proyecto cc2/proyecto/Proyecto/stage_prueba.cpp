#include "stage_prueba.h"
#include <iostream>

stage0::stage0(std::string fondo)
{
    textura_fondo.loadFromFile(fondo);
	textura_fondo2.loadFromFile("model-01.png");


	sprite_background.setTexture(textura_fondo);

	textura_piso.loadFromFile("plat.png", IntRect(0, 0, 128, 76));
	textura_cajas.loadFromFile("caja.png", IntRect(0, 0, 125, 146));
	textura_plat_mov.loadFromFile("plat_mov.png", IntRect(0, 77.76, 365, 125));
	textura_button.loadFromFile("button.png", IntRect(0,0,133,30));

	/*
	pisos.push_back(Platform(&textura_piso, sf::Vector2f(128.0f, 76.0f), sf::Vector2f(700.0f/2, 106.0f)));

	cajas.push_back(Platform(&textura_cajas, sf::Vector2f(64.0f, 64.0f), sf::Vector2f(200.0f, 300.0f)));
	cajas.push_back(Platform(&textura_cajas, sf::Vector2f(64.0f, 64.0f), sf::Vector2f(200.0f, 350.0f)));
	cajas.push_back(Platform(&textura_cajas, sf::Vector2f(64.0f, 64.0f), sf::Vector2f(250.0f, 450.0f)));
	*/

	plat_movs.push_back(Platform(&textura_plat_mov, sf::Vector2f(86.0f, 15.0f), sf::Vector2f(128.0f, 135.0f))); // 135.0f->205.0f
	plat_movs.push_back(Platform(&textura_plat_mov, sf::Vector2f(130.0f, 15.0f), sf::Vector2f(650.0f, 210.0f)));

    buttons.push_back(Platform(&textura_button, sf::Vector2f(133.0f/4, 15.0f/2), sf::Vector2f(265.0f, 118.0f)));
	buttons.push_back(Platform(&textura_button, sf::Vector2f(133.0f/4, 15.0f/2), sf::Vector2f(265.0f, 198.0f)));
	buttons.push_back(Platform(&textura_button, sf::Vector2f(133.0f/4, 15.0f/2), sf::Vector2f(440.0f, 278.0f)));
}

void stage0::procesarColisionesStageX(Player & player)
{
    sf::Vector2f direction;
	Collider cPlayer = player.getCollider();
	Collider cCaja = caja->getCollider();

	for(Platform& caja : cajas)
	{
		if (caja.getCollider().CheckCollision(cPlayer, direction, 1.0f))
			player.onCollision(direction);

	}

    for (Platform& piso : pisos)
	{
		if (piso.getCollider().CheckCollision(cPlayer, direction, 1.0f))
			player.onCollision(direction);
	}

	for (Platform& plat_mov : plat_movs)
    {
        if (plat_mov.getCollider().CheckCollision(cPlayer, direction, 1.0f))
            player.onCollision(direction);
    }

    for (Platform& button : buttons)
    {
        if (button.getCollider().CheckCollision(cPlayer, direction, 1.0f))
            player.onCollision(direction);
    }


}

void stage0::Draw(sf::RenderWindow & window, float deltaTime, Player & player)
{
    window.draw(sprite_background);

    for (Platform& caja : cajas)
		caja.Draw(window);

    for (Platform& piso : pisos)
		piso.Draw(window);

    for (Platform& plat_mov : plat_movs)
        plat_mov.Draw(window);

    for (Platform& button : buttons)
        button.Draw(window);
}

Sprite stage0::getFondo() {
	return sprite_background;
}
Sprite stage0::getPiso() {
	return sprite_piso;
}

