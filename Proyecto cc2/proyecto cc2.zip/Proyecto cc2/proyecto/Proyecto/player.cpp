#include "player.h"
#include <iostream>

Player::Player(sf::Texture *texture, sf::Vector2u imageCount, float switchTime, float speed, float jumpHeight, float vel_ataque, float vida):
	animacion(texture, imageCount, switchTime)
{
    this->speed = speed;
	this->jumpHeight = jumpHeight;
	this->vida = vida;
	row = 0;
	faceRight = true;

	body.setSize(sf::Vector2f(40, 40));
	body.setOrigin(body.getSize() / 2.0f);
	body.setPosition(100,500);
	body.setTexture(texture);
}

Player::~Player()
{

}

void Player::inputHandler(sf::RenderWindow &window)
{

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
	{
		velocity.x -= speed;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
	{
		velocity.x += speed;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
	{
		velocity.y -= speed;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
	{
		velocity.y += speed;
	}



	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && canJump)
	{
		canJump = false;
		velocity.y = -sqrtf(2.0f * 918.0f * jumpHeight);
	}


}

void Player::Update(float deltaTime, sf::RenderWindow & window)
{

	animacion.Update(row, deltaTime, faceRight);
	body.setTextureRect(animacion.uvRect);
	//body.move(velocity * deltaTime );

}

void Player::onCollision(sf::Vector2f direction)
{
    if (direction.x < 0.0f)
	{
		//colision en la izq
		velocity.x = 0.0f;
	}
	else if (direction.x > 0.0f)
	{

		//colision en la der
		velocity.x = 0.0f;
	}
	if (direction.y < 0.0f)
	{
		//colision en la bot
		velocity.y = 0.0f;
		canJump = true;
	}
	else if (direction.y > 0.0f)
	{
		//colision en el top
		velocity.y= 0.0f;
	}

}

void Player::Draw(sf::RenderWindow & window)
{
    window.draw(body);
}
