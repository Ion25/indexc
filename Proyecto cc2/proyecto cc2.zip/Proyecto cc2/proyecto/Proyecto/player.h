#pragma once
#include <SFML/Graphics.hpp>
#include "animations.h"
#include "Collider.h"
#include <math.h>

class Player
{
public:
    Player(sf::Texture *texture, sf::Vector2u imageCount, float switchTime, float speed, float jumpHeight, float vel_ataque, float vida);
	~Player();

	void inputHandler(sf::RenderWindow &window);
	void onCollision(sf::Vector2f direction);
	void Update(float deltaTime, sf::RenderWindow & window);

	void Draw(sf::RenderWindow & window);
	Collider getCollider() { return Collider(body); }
	sf::Vector2f GetPosition() { return body.getPosition(); }
	void setPosition(sf::Vector2f position) { body.setPosition(position); }
    void setCanJump(bool x) { canJump = x; }

	sf::Vector2f GetVelocity() { return velocity; }
	void setVelocity(float velX, float velY) { velocity.x = velX; velocity.y = velY;}

private:
    Animations animacion;
	unsigned int row;
	bool faceRight;

    sf::RectangleShape body;
    float speed;

    sf::Vector2f velocity;
	bool canJump;
    bool isAlive;
    bool dying;
    float jumpHeight;
    float vida;
};
