#include "stage_prueba.h"
#include "TileMap_1.h"
#include "TileMap.h"
#include <math.h>
#include <iostream>
using namespace std;
using namespace sf;

int main()
{
    // Create the main window
    //sf::RenderWindow app(sf::VideoMode(800, 600), "SFML window");
    sf::RenderWindow window(sf::VideoMode(800, 600),"Juego", sf::Style::Close | sf::Style::Resize);

    // Load a sprite to display
    sf::Texture texture;
    if (!texture.loadFromFile("cb.bmp"))
        return EXIT_FAILURE;
    sf::Sprite sprite(texture);
    sprite.setPosition(100,100);


    sf::Texture player_txtr;
    player_txtr.loadFromFile("rojo.png");
    Player player(&player_txtr, sf::Vector2u(10, 6), 0.07f, 0.30f, 0.030f, 0.6f, 100.0f);
    //sf::Vector2f pos(50,50);
    //player.setPosition(pos);
    //player.setVelocity(player.GetVelocity().x*0.91f, player.GetVelocity().y*0.99f);

    stage0 stage("");

/*
    string sLevel =   "......................................ad.........................................ad...................ad.................assss..";
			//sLevel += "......................................ad...1.1...................................ad...................ad.......qe........assss..";
			//sLevel += "......................................ase.................1.1...............1.1..ad............t......ad...........qe....asssss.";
			//sLevel += "......................................asswwwwe.......qwe.........................ad...11.....qwwwe....ad..t............qessss...";
			//sLevel += "......................................zsxxxxxxe.....qssse............qwwe...qwe..zxwe.......qssssswe..zsggxggge....qwwwssssss...";
			sLevel += ".....1..1.......1.1.....qwwwwwwwwwwe...b.1.11.b....qsxxxxgggh....qwwwsssswwwssd....zc...qwwwsssssssd...b1.1.1.b...qsssssssss....";
			sLevel += "s.........qe...........qsssssssssssse............qwsd1..........qsssssssssssssswe..11..qsssssssssssse.....qe.....qsssssss.......";
			sLevel += "wswswwwwwwsswwwwwwwwwwwsssssssssssssswwwwwwwwwwwwsssswwwwwwwwwwwssssssssssssssssswwwwwwsssssssssssssswwwwwwwwwwwwsssssss........";
			sLevel += "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss..........";
*/


    //string sLevel =   "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
    /*
    string sLevel =   "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
			//sLevel += "......................................ad...1.1...................................ad...................ad.......qe........assss..";
			//sLevel += "......................................ase.................1.1...............1.1..ad............t......ad...........qe....asssss.";
			//sLevel += "......................................asswwwwe.......qwe.........................ad...11.....qwwwe....ad..t............qessss...";
			//sLevel += "......................................zsxxxxxxe.....qssse............qwwe...qwe..zxwe.......qssssswe..zsggxggge....qwwwssssss...";
			sLevel += ".....1..1.......1.1.....qwwwwwwwwwwe...b.1.11.b....qsxxxxgggh....qwwwsssswwwssd....zc...qwwwsssssssd...b1.1.1.b...qsssssssss....";
			sLevel += "q.........qe...........qsssssssssssse............qwsd1..........qsssssssssssssswe..11..qsssssssssssse.....qe.....qsssssss.......";
			sLevel += "wqwqwwwwwwsswwwwwwwwwwwsssssssssssssswwwwwwwwwwwwsssswwwwwwwwwwwssssssssssssssssswwwwwwsssssssssssssswwwwwwwwwwwwsssssss........";
			sLevel += "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss..........";


    string  sLevel = "wwwwwwwwwwwwwwwwwwww";
            sLevel += "wwwwwwwwwwwwwwwwwwww";
            sLevel += "ww................ww";
            sLevel += "ww............wwwwww";
            sLevel += "ww................ww";
            sLevel += "ww.........qqqqqqwww";
            sLevel += "ww................ww";
            sLevel += "ww................ww";
            sLevel += "ww.......qqqqq....ww";
            sLevel += "ww..............wwww";
            sLevel += "wwqqq..........qqqww";
            sLevel += "ww................ww";
            sLevel += "ww................ww";
            sLevel += "wwwwwwwwwwwwwwwwwwww";
            sLevel += "wwwwwwwwwwwwwwwwwwww";

    */

    string  sLevel = "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
            sLevel += "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
            sLevel += "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww.....qqqqqqqqqqqqqqqqqqqqqqqqqqqwwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww.....qqqqqqqqqqqqqqqqqqqq.......wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww.............qqqqqqqqqqqqqqqqqqqwwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww....qqqqq.......................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww............qqqqqqqqq...........wwww";
            sLevel += "wwwwq..............................qwwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww.................qqqqqqqqqq.....wwww";
            sLevel += "wwwwqqqqqq..........................wwww";
            sLevel += "wwww................................wwww";
            sLevel += "wwww.............................qqqwwww";
            sLevel += "wwww..........................qqqqqqwwww";
            sLevel += "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
            sLevel += "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";
            sLevel += "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww";

            //sLevel += "wwww.................wwww";

    //TileMap maps("Tiles.png", 128,9, sLevel, 128, 128);
    //TileMap_1 maps("Tiles.png", 20,15, sLevel, 40, 40);
    TileMap_1 maps("Tiles.png", 40,30, sLevel, 20, 20);
    Clock reloj;
	float deltaTime = 0.0f;

	/*
	// Start the game loop
    while (app.isOpen())
    {
        // Process events
        sf::Event event;
        while (app.pollEvent(event))
        {
            // Close window : exit
            if (event.type == sf::Event::Closed)
                app.close();

            //PRUEBAS***
            /*
            if(event.type == sf::Event::KeyPressed)
                if(sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
                {
                    sf::Vector2f pos1(50+i,50+i);
                    sprite.setPosition(pos1);
                    i++;
                }*


        }

        // Clear screen
        app.clear();

        // Draw the sprite
        app.draw(sprite);

        //PRUEBAS****
        player.Update(1.0,app);
        player.inputHandler(app);
        player.Draw(app);

        // Update the window
        app.display();
    }
    */

    while (window.isOpen())
	{

		deltaTime = reloj.restart().asSeconds();
		Event evento;
		while (window.pollEvent(evento))
		{
			switch (evento.type)
			{
			case Event::Closed:
				window.close();
				break;



			}

		}

		window.clear();
		//window.setView(vista);
		maps.CheckCollisionTileMap(deltaTime,window,player);
		stage.procesarColisionesStageX(player);
		//vista.setCenter(player.GetPosition().x, player.GetPosition().y - 50 );
        stage.Draw(window, deltaTime, player);
		maps.TileMapDraw(window, deltaTime, player);

		//window.draw(map);
		//stage1.Draw(window, deltaTime,player);
		player.Draw(window);
		window.display();
		cout << player.GetPosition().x <<" , "<< player.GetPosition().y << endl;

	}

    return EXIT_SUCCESS;
}
